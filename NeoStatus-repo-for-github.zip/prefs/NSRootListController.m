#import <Preferences/PSListController.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <notify.h>

@interface NSRootListController : PSListController
@end

@implementation NSRootListController
- (NSArray *)specifiers {
    if (!_specifiers) _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    return _specifiers;
}
- (void)resetPreferences {
    CFStringRef domain = CFSTR("com.neostatus.tweak");
    NSDictionary *defaults = @{
        @"Enabled": @YES,
        @"PreviewGestureEnabled": @NO,
        @"DiagnosticsEnabled": @YES,
        @"GlassEnabled": @YES,
        @"RoundedModulesEnabled": @YES,
        @"ColoredGlyphsEnabled": @YES,
        @"MediaStyleEnabled": @YES,
        @"NeoStatus.ControlLayout.v2": @[@"wifi", @"cellular", @"bluetooth", @"airplane", @"hotspot", @"orientation", @"vpn", @"silent", @"focus", @"record", @"flashlight", @"screenmirror"]
    };
    for (NSString *key in defaults) CFPreferencesSetAppValue((__bridge CFStringRef)key, (__bridge CFPropertyListRef)defaults[key], domain);
    CFPreferencesAppSynchronize(domain);
    notify_post("com.neostatus.tweak/preferences.changed");
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"NeoStatus" message:@"设置已恢复默认值。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)openDiagnostics {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSMutableArray<NSString *> *candidates = [NSMutableArray arrayWithObject:@"/var/mobile/Library/Logs/NeoStatus"];
    NSString *home = NSHomeDirectory();
    if (home.length) [candidates addObject:[[home stringByAppendingPathComponent:@"Library/Logs"] stringByAppendingPathComponent:@"NeoStatus"]];
    [candidates addObject:@"/tmp/NeoStatus-Logs"];
    NSString *path = candidates.firstObject;
    BOOL found = NO;
    for (NSString *candidate in candidates) {
        BOOL isDirectory = NO;
        if ([fm fileExistsAtPath:candidate isDirectory:&isDirectory] && isDirectory) {
            path = candidate;
            found = YES;
            if ([fm fileExistsAtPath:[candidate stringByAppendingPathComponent:@"LATEST.txt"]]) break;
        }
    }
    UIPasteboard.generalPasteboard.string = path;
    NSString *message = found
        ? [NSString stringWithFormat:@"检测到诊断目录，路径已复制：\n%@", path]
        : [NSString stringWithFormat:@"尚未检测到诊断目录。首选路径已复制：\n%@\n\n请先在 SpringBoard 中请求生成诊断快照。", path];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"诊断目录" message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)writeDiagnosticSnapshot {
    notify_post("com.neostatus.tweak/diagnostics.request");
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"NeoStatus" message:@"已向 SpringBoard 发送诊断请求。请稍后检查诊断目录。" preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}
@end
