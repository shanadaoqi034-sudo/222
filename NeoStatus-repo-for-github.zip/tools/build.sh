#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
cd "$ROOT"
python3 tools/validate_project.py
if [ -z "${THEOS:-}" ] || [ ! -d "$THEOS/makefiles" ]; then
  echo "ERROR: THEOS is not configured. Set THEOS to your RootHide Theos directory." >&2
  exit 2
fi
make clean package
