#!/usr/bin/env python3
"""Offline structural checks for the NeoStatus Theos source tree."""
from pathlib import Path
import plistlib
import re
import sys

root = Path(__file__).resolve().parents[1]
checks = []

def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

plist_files = [
    "prefs/Resources/Info.plist",
    "prefs/Resources/Root.plist",
    "layout/Library/PreferenceLoader/Preferences/NeoStatusPrefs.plist",
]
parsed = {}
for rel in plist_files:
    try:
        with (root / rel).open("rb") as f:
            parsed[rel] = plistlib.load(f)
        check(f"plist parse: {rel}", True)
    except Exception as exc:
        check(f"plist parse: {rel}", False, str(exc))

required = [
    "Makefile", "control", "NeoStatus.plist", "Tweak.xm", "NSConfig.h", "NSConfig.m",
    "NSRuntimeProbe.h", "NSRuntimeProbe.m", "NSControlCenterViewController.h",
    "NSControlCenterViewController.m", "NSControlTile.h", "NSControlTile.m",
    "NSGlassPanel.h", "NSGlassPanel.m", "prefs/Makefile", "prefs/NSRootListController.m",
    "docs/INTEGRATION-STATUS.md", "docs/UPSTREAM-PORT-MAP.md", "tools/build.sh", "LICENSE", "THIRD_PARTY_NOTICES.md"
]
for rel in required:
    check(f"required file: {rel}", (root / rel).is_file())

entry = parsed.get("layout/Library/PreferenceLoader/Preferences/NeoStatusPrefs.plist", {}).get("entry", {})
check("PreferenceLoader entry bundle", entry.get("bundle") == "NeoStatusPrefs" and entry.get("isController") is True)
info = parsed.get("prefs/Resources/Info.plist", {})
check("PreferenceBundle identifier", info.get("CFBundleIdentifier") == "com.neostatus.preferences")
check("PreferenceBundle principal class", info.get("NSPrincipalClass") == "NSRootListController")

root_plist = parsed.get("prefs/Resources/Root.plist", {})
items = root_plist.get("items", [])
keys = {item.get("key") for item in items if isinstance(item, dict)}
expected = {"Enabled", "PreviewGestureEnabled", "DiagnosticsEnabled", "GlassEnabled", "RoundedModulesEnabled", "ColoredGlyphsEnabled", "MediaStyleEnabled"}
check("settings keys", expected.issubset(keys), f"missing: {sorted(expected - keys)}")
button_actions = {item.get("action") for item in items if isinstance(item, dict)}
prefs_source = (root / "prefs/NSRootListController.m").read_text(errors="replace")
for action in ("openDiagnostics", "writeDiagnosticSnapshot", "resetPreferences"):
    check(f"settings action implemented: {action}", action in button_actions and f"- (void){action}" in prefs_source)

makefile = (root / "Makefile").read_text(errors="replace")
control = (root / "control").read_text(errors="replace")
check("RootHide scheme", "THEOS_PACKAGE_SCHEME = roothide" in makefile)
check("iPhone 15 Pro arm64e slice", re.search(r"^ARCHS\s*=\s*arm64e\s*$", makefile, re.M) is not None)
check("RootHide package architecture", "DEB_ARCH = iphoneos-arm64e" in makefile and "Architecture: iphoneos-arm64e" in control)
check("iOS 17.0 target", "TARGET = iphone:clang:latest:17.0" in makefile and "firmware (>= 17.0)" in control)
check("PreferenceBundle subproject", "SUBPROJECTS += prefs" in makefile)
check("ElleKit + PreferenceLoader dependencies", "ellekit" in control and "preferenceloader" in control)
check("PreferenceLoader staged from matching path", "NeoStatusPrefs.plist" in makefile and (root / "layout/Library/PreferenceLoader/Preferences/NeoStatusPrefs.plist").is_file())

config = (root / "NSConfig.m").read_text(errors="replace")
tweak = (root / "Tweak.xm").read_text(errors="replace")
controller = (root / "NSControlCenterViewController.m").read_text(errors="replace")
check("shared preference domain", 'com.neostatus.tweak' in config and 'com.neostatus.tweak' in prefs_source)
check("Darwin preference notification", "com.neostatus.tweak/preferences.changed" in config and "notify_post" in config)
check("preview gesture opt-in", 'PreviewGestureEnabled' in tweak and 'defaultValue:NO' in tweak)
check("preview controls use public brightness API", "UIScreen.mainScreen.brightness = sender.value" in controller)
check("preview controls use MPVolumeView", "MPVolumeView" in controller)
check("flashlight uses AVCapture torch API", "setTorchModeOnWithLevel" in controller and "AVCaptureTorchModeOff" in controller)
check("header clock and battery refresh", "refreshHeader" in controller and "UIDeviceBatteryLevelDidChangeNotification" in controller)
check("live appearance preference refresh", "refreshAppearanceFromPreferences" in controller and "CFNotificationCenterAddObserver" in controller)
check("edit-mode taps do not activate controls", "if (self.editingControls) return;" in controller)
check("master switch dismisses open preview", 'boolForKey:@"Enabled" defaultValue:YES' in controller and 'dismissViewControllerAnimated:NO' in controller)
probe = (root / "NSRuntimeProbe.m").read_text(errors="replace")
check("diagnostic snapshot directories are private", "NSFilePosixPermissions: @0700" in probe)
check("diagnostic report files are private", "NSFilePosixPermissions: @0600" in probe)
check("package version metadata is 1.0.0", "Version: 1.0.0" in control and "1.0.0" in info.get("CFBundleShortVersionString", ""))

integration = (root / "docs/INTEGRATION-STATUS.md").read_text(errors="replace")
check("native takeover limitation documented", "not" in integration.lower() and "native Control Center" in integration)
check("unimplemented upstream ports documented", "has not been transplanted" in integration or "not copied" in integration)
check("corrupt saved layout guarded", "isKindOfClass:NSArray.class" in controller)
check("glass preference refreshes backdrop", "self.backdrop.effect = glassEnabled" in controller)
check("continuous corner curve used", "kCACornerCurveContinuous" in (root / "NSGlassPanel.m").read_text(errors="replace"))
check("single target arm64e build for iPhone 15 Pro", re.search(r"^ARCHS\s*=\s*arm64e\s*$", makefile, re.M) is not None)
check("SpringBoard install target configured", "INSTALL_TARGET_PROCESSES = SpringBoard" in makefile)
check("first source release documentation", "首个源码发布版" in (root / "README.md").read_text(errors="replace"))
check("upstream source not vendored statement", "does not include copied source files" in (root / "THIRD_PARTY_NOTICES.md").read_text(errors="replace"))

failed = 0
for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + "  " + name + (f" — {detail}" if detail else ""))
    failed += not ok
print(f"\n{len(checks)-failed}/{len(checks)} structural checks passed")
sys.exit(1 if failed else 0)
