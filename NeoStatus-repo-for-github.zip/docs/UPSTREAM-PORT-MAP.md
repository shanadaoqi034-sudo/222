# Upstream project map and integration constraints

NeoStatus currently contains no vendored source files from these upstream projects. The integration plan separates ideas and interfaces from code that cannot safely or lawfully be copied into this tree without verifying its license.

| Project | Verified upstream purpose | Intended NeoStatus role | Current status |
|---|---|---|---|
| CCAster-iOS-15 | SpringBoard-side Control Center layout, paging, add sheet, edit/reorder and resize behavior | Reference for a native layout/editor engine | Not transplanted. Its README says iOS 15 through 17, but the same README declares package firmware `>= 11.0, << 17.0`; it lists tested devices on iOS 15/16. Exact iOS 17.0 support is therefore not established. No license was confirmed in the visible repository files. |
| CC26 | iOS 18-inspired Control Center appearance: rounded modules, media module, colored slider glyphs and top action buttons | Visual reference for the NeoStatus style engine | Not transplanted. Its README says iOS ~13–17 and explicitly says it was only tested on iOS 15. No LICENSE file is visible in the repository's top-level file list, so its implementation code is not copied. |
| PowerModule | Example third-party power-actions Control Center module (respring, reboot, uicache, safemode) implemented using `CCUIContentModule` | Architectural reference for a future optional native module | Not transplanted. Repository exposes an MIT license (copyright Tommy Muir, 2020); any copied source must retain its notice. It is an example module, not a generic module loader. iOS 17 compatibility remains unverified. |
| CCSupport | Third-party Control Center module support / registration ecosystem | Potential dependency if optional native modules are implemented | Not integrated; dependency and iOS 17/RootHide compatibility need validation first. |

## Integration rules

1. Do not treat a README compatibility range as proof that a private class or selector has a stable ABI on iOS 17.0.
2. Do not copy source from repositories without a license grant. Public visibility alone is not a license.
3. Keep the native overlay hook, layout engine, visual styling and module bundle as separate components so one failure can be disabled independently.
4. Do not enable a native Control Center hook until a diagnostic snapshot from the target iPhone 15 Pro / iOS 17.0 / Relaxin confirms class availability and method encodings, followed by device-side lifecycle testing.
5. PowerModule's `CCUIContentModule` example is a starting point for an optional module, not a substitute for CCSupport or an overall module repository.
