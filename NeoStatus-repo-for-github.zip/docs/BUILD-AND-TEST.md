# Build and test checklist

## Build environment

1. Use macOS with Xcode Command Line Tools.
2. Install the RootHide-compatible Theos distribution and an iOS SDK supported by that toolchain.
3. Set `THEOS` to that Theos checkout.
4. Confirm the target bootstrap has ElleKit and PreferenceLoader.
5. Run `./tools/build.sh` from the project root. The script runs the offline validator first, then `make clean package`.

## Package inspection

Before installing, inspect the generated DEB and verify:

- Package ID is `com.neostatus.tweak`.
- Architecture is `iphoneos-arm64e`.
- The tweak filter plist is installed under `Library/MobileSubstrate/DynamicLibraries/`.
- `NeoStatusPrefs.bundle` is installed under `Library/PreferenceBundles/`.
- `NeoStatusPrefs.plist` is installed under `Library/PreferenceLoader/Preferences/`.
- Dependencies include ElleKit and PreferenceLoader.

## Device test

1. Keep a known safe-mode / package-removal recovery path available.
2. Install the package and respring.
3. Verify Settings > NeoStatus appears.
4. Verify the preview gesture is disabled by default.
5. Enable the preview gesture, return to SpringBoard and triple-tap the Home Screen to open the prototype.
6. Disable the gesture and verify it is removed.
7. Change glass, rounded-module, glyph and media preferences; close and reopen the preview to verify the change.
8. Test brightness, volume, media playback and flashlight individually.
9. Verify that placeholder tiles display an explanation and do not claim to change system state.
10. Request a diagnostic snapshot and inspect its files before sharing.

## Recovery

If SpringBoard enters a respring loop, use the jailbreak safe mode or package manager to disable/remove `com.neostatus.tweak`. Do not rely on a Settings switch if SpringBoard cannot stay alive long enough to read it.
