# NeoStatus 1.0.0 integration status

## What this first source release actually implements

- SpringBoard-only Logos injection.
- An opt-in triple-tap **preview entry**, disabled by default and configurable in Settings > NeoStatus.
- A UIKit visual preview with two pages, glass-style panels, live clock/battery/Low Power Mode header, brightness adjustment, system volume view, media play/pause, flashlight toggle, and locally persisted tile ordering.
- A PreferenceBundle registered with PreferenceLoader.
- Shared CFPreferences domain (`com.neostatus.tweak`) and Darwin notifications for preference changes and diagnostic requests.
- Runtime diagnostics with a bounded snapshot set, private directory/file permissions, and a limited inventory of relevant runtime classes, method encodings and injection markers.
- RootHide Theos configuration targeting the iPhone 15 Pro's arm64e architecture and iOS 17.0 deployment.

## What is intentionally not claimed as implemented

- This is **not** a replacement for the native Control Center gesture or Apple's private ControlCenter overlay/controller.
- Wi-Fi, Bluetooth, cellular, Airplane Mode, VPN, Hotspot, Focus, orientation lock, screen mirroring and screen recording tiles are visual placeholders. They do not claim to reflect or change live system state.
- CCAster's native paging/editing/resize engine has not been transplanted. Its iOS 17 private API compatibility must be proven on the target device before hooking it.
- CC26 source has not been copied into this tree. Its repository describes an iOS 18-inspired design, claims iOS ~13–17 compatibility, and says it was only tested on iOS 15. No implementation code is copied.
- PowerModule is used as an architectural reference for an optional power-actions `CCUIContentModule`; its code is not included. The example module still needs iOS 17/RootHide runtime validation and CCSupport integration.
- No global iOS 26 status-bar replacement is implemented.
- No compiled DEB or device validation is included. The current build environment does not contain Theos or an iOS SDK.

## Why native Control Center takeover is deferred

The supplied 0.5.1 project and this 1.0.0 release contain a UIKit preview controller and a runtime probe, but do not contain the CCAster coordinator implementation, a native overlay hook, or a working third-party module bundle. Runtime class names and method encodings are observational evidence only; they do not establish selector ABI, lifecycle timing or safe hook points. Native integration requires a diagnostic snapshot captured on the target iPhone 15 Pro / iOS 17.0 / Relaxin after opening the stock Control Center, followed by device-side lifecycle testing.

## Build target

- Device: iPhone 15 Pro (arm64e)
- OS deployment target: iOS 17.0
- Bootstrap scheme: RootHide (`THEOS_PACKAGE_SCHEME=roothide`)
- Injection: ElleKit-compatible Logos tweak
- Settings: PreferenceLoader / Preferences bundle

Build on a configured RootHide Theos environment with:

```sh
./tools/build.sh
```

The generated DEB must be inspected before installation to confirm the package architecture, tweak filter, PreferenceLoader entry and PreferenceBundle. Keep a safe-mode or package-removal path available before respringing.
