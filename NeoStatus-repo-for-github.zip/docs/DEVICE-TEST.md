# Device test checklist — iPhone 15 Pro / iOS 17.0

This checklist has not yet been executed on the target device.

- [ ] Confirm Relaxin + RootHide + ElleKit are active.
- [ ] Install the compiled DEB with a safe-mode/removal path available.
- [ ] Confirm Settings > NeoStatus appears.
- [ ] Confirm the master switch disables the preview and removes its gesture.
- [ ] Confirm triple-tap preview is off after a fresh install.
- [ ] Enable triple-tap preview and open/close the preview several times.
- [ ] Test portrait and landscape layout, including rotation while the preview is open.
- [ ] Test local tile add/remove/reorder and confirm layout persists after dismissal/respring.
- [ ] Test brightness, volume, media playback and flashlight.
- [ ] Confirm placeholder system toggles do not report fake live state.
- [ ] Toggle glass/rounded/glyph/media preferences and confirm the preview updates.
- [ ] Generate a diagnostic snapshot and inspect all four text files.
- [ ] Open stock Control Center and collect another diagnostic snapshot for future native integration work.
- [ ] Confirm no SpringBoard crash, respring loop or persistent console error.
