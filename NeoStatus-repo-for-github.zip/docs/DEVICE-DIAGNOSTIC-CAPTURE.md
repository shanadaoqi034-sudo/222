# Target-device diagnostic capture

This procedure is for the target iPhone 15 Pro running iOS 17.0 with Relaxin, RootHide, and ElleKit. It does not enable private API hooks.

1. Install the NeoStatus package only after a successful Theos build and confirm that Settings > NeoStatus appears.
2. Respring once and let SpringBoard settle.
3. Open the stock iOS Control Center, wait several seconds, then close it. This allows lazily loaded Control Center classes to enter the SpringBoard runtime.
4. Open Settings > NeoStatus and tap **请求生成诊断快照**. The PreferenceBundle posts a Darwin notification; the SpringBoard tweak writes the snapshot.
5. Tap **复制诊断目录** and retrieve the newest `snapshot-*` directory.
6. Share the four text files from that snapshot: `summary.txt`, `jailbreak-environment.txt`, `control-center-statusbar-classes.txt`, and `selected-methods-and-type-encodings.txt`.

The snapshot intentionally avoids serial numbers, Apple IDs, installed-app lists, Wi-Fi identifiers, and personal content. Review the files before sharing anyway.

A class name or method type encoding is not proof that a private hook is safe. Native takeover must be implemented only after checking class availability, exact method signatures, lifecycle timing, and rollback behavior on this OS build.
