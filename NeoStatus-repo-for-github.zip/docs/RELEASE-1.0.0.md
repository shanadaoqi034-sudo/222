# NeoStatus 1.0.0 — first source release

Release type: source-only first release.

Included: SpringBoard preview panel, Settings bundle, opt-in preview gesture, local tile editor, public-API brightness/volume/media/flashlight actions, runtime diagnostics and RootHide Theos project files.

Not included: native Control Center takeover, full CCAster/CC26/PowerModule integration, global status-bar replacement or a compiled DEB.

Validation: offline structural validator and plist parsing only. Theos compile and target-device tests remain outstanding.
