# NeoStatus 1.0.0 — release status

## Release scope

The first source release is a SpringBoard-injected UIKit visual preview and diagnostic utility for iOS 17.0 / RootHide / ElleKit. It is not a native Control Center replacement.

## Implemented in source

- SpringBoard-only Logos injection filter.
- Opt-in triple-tap preview entry, disabled by default.
- Two-page visual preview with glass-style tiles and local editable ordering.
- Brightness, system volume, media play/pause and flashlight controls through public frameworks/APIs.
- Explicitly non-functional visual placeholders for system toggles that are not implemented.
- PreferenceBundle + PreferenceLoader entry for Settings > NeoStatus.
- Shared CFPreferences domain and Darwin notifications for preference changes and diagnostic requests.
- Immediate dismissal of an open preview when the master switch is disabled.
- Runtime diagnostics with bounded retention and private file permissions.
- RootHide Theos project configuration for the arm64e target and iOS 17.0.

## Not implemented / not validated

- Native Control Center gesture or overlay replacement.
- CCAster paging/edit/resize engine transplant.
- CC26 full visual Hook transplant.
- PowerModule custom `CCUIContentModule` module and CCSupport registration.
- Global status-bar replacement.
- Theos compilation, DEB generation, installation, and iOS 17.0 Relaxin device validation.

## Release checks

The offline validator checks project structure, plist syntax, metadata, preference wiring and documented feature boundaries. Passing those checks is not equivalent to an Objective-C compile, DEB build, installation test or device test.
